# Code for project "Predicting the outcome for patients with heart failure",
# DIT862 HT2020, Group 5.
# Created by Siri Dahlgren, Karl Griphammar, Viktoria Karlsson

# Successfully tested on:
# * Spyder version: 4.1.5
# * Python version: 3.8.3 64-bit
# * Qt version: 5.9.7
# * PyQt5 version: 5.9.2
# * Operating System: Windows 10

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, recall_score, f1_score
from mlxtend.evaluate import mcnemar_table # pip install mlxtend if the module does not load
from mlxtend.evaluate import mcnemar as mc


data = pd.read_csv('heart_failure_clinical_records_dataset.csv')

# Training-validation-test split:
testsplit=int(0.9*len(data.index))
valsplit=int(0.6*len(data.index))
training_data=data.iloc[:valsplit,:]
val_data=data.iloc[valsplit:testsplit,:]
test_data=data.iloc[testsplit:,:] # Unused until the final step.

# Creating correlation matrix (heatmap):
corr = training_data.corr()
sns.set_theme(style="white")

# Generate a mask for the upper triangle
mask = np.triu(np.ones_like(corr, dtype=bool))

fig, ax = plt.subplots(figsize=(11, 9))

# Generate a colormap
cmap = sns.diverging_palette(230, 20, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5}, annot = True)
plt.show()

# Highest correlation: age, serum creatinine, serum sodium, ejection. We choose
# these variables as our predictive variables for the model.

# Computing Q-Q plots for three of the variables (excluding serum sodium)

# Choose 50 points:
ps = np.linspace(0,1,51)
q_vars = ['age', 'ejection_fraction', 'serum_creatinine']
qs = []
for var in q_vars:
    q1 = [training_data[var].quantile(p) for p in ps]
    q2 = [val_data[var].quantile(p) for p in ps]
    qs.append([q1,q2])

# Plotting the Q-Q plots:
fontsize_labels = 16
fontsize_title = 18
    
fig, axes = plt.subplots(3, 1, figsize=(5,15), dpi=100, constrained_layout=True)

ax1 = axes[0]
ax1.scatter(qs[0][0], qs[0][1])

ax2 = axes[1]
ax2.scatter(qs[1][0], qs[1][1])

ax3 = axes[2]
ax3.scatter(qs[2][0], qs[2][1])

for i, ax in enumerate(fig.axes):
    ax.set_xlabel("Training quantiles")
    ax.set_ylabel("Validation quantiles")
    ax.set_title(q_vars[i], fontsize = fontsize_labels)

plt.show()

# Plotting histograms of all variables of interest:
bins = 15
fig, axes = plt.subplots(2,2, figsize = (20,20),constrained_layout=True)
ax1 = axes[0][0]
training_data.pivot(columns='DEATH_EVENT').age.plot(kind='hist',stacked=True, edgecolor='black', ax = ax1, title='Age', bins=bins, range=[data['age'].min(),data['age'].max()])
ax1.set_xticks(np.arange(data['age'].min(),data['age'].max() + 1, (data['age'].max()-data['age'].min())/bins))

ax2 = axes[0][1]
training_data.pivot(columns='DEATH_EVENT').serum_creatinine.plot(kind='hist',stacked=True, edgecolor='black', ax=ax2, title='Serum Creatinine', bins=bins, range=[data['serum_creatinine'].min(),data['serum_creatinine'].max()])
ax2.set_xticks(np.arange(data['serum_creatinine'].min(),data['serum_creatinine'].max() + 1, (data['serum_creatinine'].max()-data['serum_creatinine'].min())/bins))

ax3 = axes[1][0]
training_data.pivot(columns='DEATH_EVENT').serum_sodium.plot(kind='hist',stacked=True, edgecolor='black', ax=ax3, title='Serum Sodium', bins=bins, range=[data['serum_sodium'].min(),data['serum_sodium'].max()])
ax3.set_xticks(np.arange(data['serum_sodium'].min(),data['serum_sodium'].max() + 1, (data['serum_sodium'].max()-data['serum_sodium'].min())/bins))

ax4 = axes[1][1]
training_data.pivot(columns='DEATH_EVENT').ejection_fraction.plot(kind='hist',stacked=True, edgecolor='black',ax=ax4, title='Ejection Fraction', bins=bins, range=[data['ejection_fraction'].min(),data['ejection_fraction'].max()])
ax4.set_xticks(np.arange(data['ejection_fraction'].min(),data['ejection_fraction'].max() + 1, (data['ejection_fraction'].max()-data['ejection_fraction'].min())/bins))

for i, ax in enumerate(fig.axes):
    ax.yaxis.label.set_size(fontsize_labels)
    ax.title.set_size(fontsize_title)
    ax.tick_params(axis='x', which='major', labelsize=15, rotation = 45)
fig.suptitle('Histograms of variables of interest', fontsize = 20)
plt.show()

# Plotting boxplots:
fig, axes = plt.subplots(1,4, figsize = (10,10))
ax1 = axes[0]
ax1.boxplot(training_data['ejection_fraction'])
ax1.set_xlabel('Ejection fraction', fontsize = fontsize_labels)
ax1.set_ylabel('Frequency', fontsize = fontsize_labels)

ax2 = axes[1]
ax2.boxplot(training_data['serum_creatinine'])
ax2.set_xlabel('Serum Creatinine', fontsize = fontsize_labels)

ax3 = axes[2]
ax3.boxplot(training_data['serum_sodium'])
ax3.set_xlabel('Serum Sodium', fontsize = fontsize_labels)

ax4 = axes[3]
ax4.boxplot(training_data['age'])
ax4.set_xlabel('Age', fontsize = fontsize_labels)
plt.show()

# Printing summary statistics of the variables:
pred_vars = ['age', 'ejection_fraction', 'serum_creatinine', 'serum_sodium']

for var in pred_vars:
    rnge = [min(training_data[var]), max(training_data[var])]
    mean = training_data[var].mean()
    std = training_data[var].std()
    quantiles = [training_data[var].quantile(0.25), training_data[var].quantile(0.5), training_data[var].quantile(0.75)]
    
    print(f"\n{var}:\nRange: {rnge}\nSample mean = {mean:.3f}\nSample standard deviation: {std:.3f}",
          f"\nQuantiles:\n\t0.25: {quantiles[0]}\n\t0.5: {quantiles[1]}\n\t0.75: {quantiles[2]}")
    
# -----------------------------------------------------------
# Showing dependecy between variables:
    
# Correlation matrix (heatmap):
corr = training_data[pred_vars].corr()

sns.set_theme(style="white")
mask = np.triu(np.ones_like(corr, dtype=bool))
fig, ax = plt.subplots(figsize=(11, 9))
cmap = sns.diverging_palette(230, 20, as_cmap=True)
sns.heatmap(corr,mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5}, annot = True)
plt.show()

# Scatterplots of the predictive variables, colored by class variable:
fig, axes = plt.subplots(2,3, figsize = (15,10), constrained_layout=True)
colors = {0:'#1f77b4', 1:'#ff7f0e'}
groups = training_data.groupby('DEATH_EVENT')


for key, group in groups:
    group.plot(ax=axes[0][0], kind='scatter', x='age', y='serum_creatinine', label=key, color=colors[key])
    axes[0][0].set_title('Serum Creatinine vs Age', fontsize = fontsize_title)
    
    group.plot(ax=axes[0][1], kind='scatter', x='age', y='serum_sodium', label=key, color=colors[key])
    axes[0][1].set_title('Serum Sodium vs Age', fontsize = fontsize_title)
    
    group.plot(ax=axes[0][2], kind='scatter', x='age', y='ejection_fraction', label=key, color=colors[key])
    axes[0][2].set_title('Ejection fraction vs Age', fontsize = fontsize_title)
    
    group.plot(ax=axes[1][0], kind='scatter', x='serum_creatinine', y='serum_sodium', label=key, color=colors[key])
    axes[1][0].set_title('Serum Sodium vs Serum Creatinine', fontsize = fontsize_title)
    
    group.plot(ax=axes[1][1], kind='scatter', x='serum_creatinine', y='ejection_fraction', label=key, color=colors[key])
    axes[1][1].set_title('Ejection Fraction vs Serum Creatinine', fontsize = fontsize_title)
    
    group.plot(ax=axes[1][2], kind='scatter', x='serum_sodium', y='ejection_fraction', label=key, color=colors[key])
    axes[1][2].set_title('Ejection fraction vs Serum Sodium', fontsize = fontsize_title)

for i, ax in enumerate(fig.axes):
    ax.xaxis.label.set_size(fontsize_labels)
    ax.yaxis.label.set_size(fontsize_labels)
    ax.legend(title='Death Event', framealpha = 0.5)
    
fig.suptitle('Pairwise scatterplots of variables of interest', fontsize=20)
plt.show()

# -----------------------------------------------------------
# Comparing probability distributions for three selected variables (excluding serum sodium):

means=training_data[['age','serum_creatinine','ejection_fraction','serum_sodium']].mean()
stds=training_data[['age','serum_creatinine','ejection_fraction','serum_sodium']].std()
percent=np.linspace(0.01,0.99,10)

# Age compared to discrete uniform distribution
a=training_data['age'].min()
b=training_data['age'].max()

# create probability plot

fig,ax=plt.subplots(nrows=2,ncols=1,num="Comparisons of feature age", figsize=(9.0,4.8))
fig.tight_layout(pad=2.0,w_pad=3.0,h_pad=3.0)
prob_age_uni=stats.probplot(training_data['age'],sparams=(a,b),dist=stats.randint,plot=ax[0])
ax[0].set_title('Probability plot for discrete uniform distribution versus age')
print(prob_age_uni[1])
# we get slope, intercept and r for the fitted line. R^2 is the proportion of variance in the dependent variable that can be explained by the linear regression. Higher R^2=better model. R is the Pearson correlation koefficient, as we only have one predictor variable. 

# fit a line to quantiles and look at residuals
randint_quant=stats.randint.ppf(percent,a,b)
data_quant_age=np.quantile(training_data['age'],percent,interpolation='higher')
poly_age=np.polyfit(data_quant_age,randint_quant,deg=1,full=True)
# k=1.09, sum of squared residuals=205
residuals_randint_age=[(poly_age[0][0]*data_quant_age[i]+poly_age[0][1])-randint_quant[i] for i in range(len(percent))]
#print(residuals_randint_age)

# -----------------------------------------------------------
# age compared to normal distribution

# create probability plot
prob_age_norm=stats.probplot(training_data['age'],sparams=(means[0],stds[0]),dist=stats.norm,plot=ax[1])
ax[1].set_title('Probability plot for normal distribution versus age')
print(prob_age_norm[1])
# k=0.996, r=0.99
plt.show()
# perform ks test for statistically significant distance between cdfs, null hypothesis: data is from the given distribution
ks=stats.kstest(training_data['age'],'norm',args=(means[0],stds[0]))
print(f'Ks test for age vs norm: {ks}')
# p=0.08
# returns ks statistics and p value

# compare quantiles
norm_quant_age=stats.norm.ppf(percent,loc=means[0],scale=stds[0])
poly_norm_age=np.polyfit(data_quant_age,norm_quant_age,deg=1,full=True)
# k=0.99, ssr=94
residuals_norm_age=[(poly_norm_age[0][0]*data_quant_age[i]+poly_norm_age[0][1])-norm_quant_age[i] for i in range(len(percent))]
#print(residuals_norm_age)

# -----------------------------------------------------------
# serum creatinine and ejection fraction compared to normal distribution

# create probplot
fig1,ax1=plt.subplots(nrows=2,ncols=1,num="Comparisons to normal distribution", figsize=(9.0,4.8))
fig1.tight_layout(pad=2.0,w_pad=3.0,h_pad=3.0)
prob_creatinine=stats.probplot(training_data['serum_creatinine'],sparams=(means[1],stds[1]),dist=stats.norm,plot=ax1[0])
ax1[0].set_title('Probability plot for normal distribution versus serum creatinine')
print(prob_creatinine[1])
# k=0.77, r=0.76
# perform ks test
ks=stats.kstest(training_data['serum_creatinine'],'norm',args=(means[1],stds[1]))
print(f'Ks test for creatinine vs norm: {ks}')

prob_ejection=stats.probplot(training_data['ejection_fraction'],sparams=(means[2],stds[2]),dist=stats.norm,plot=ax1[1])
ax1[1].set_title('Probability plot for normal distribution versus ejection fraction')
print(prob_ejection[1])
plt.show()
ks=stats.kstest(training_data['ejection_fraction'],'norm',args=(means[2],stds[2]))
print(f'Ks test for ejection vs norm: {ks}')

# compare quantiles
norm_quant_creatinine=stats.norm.ppf(percent,loc=means[1],scale=stds[1])
data_quant_creatinine=np.quantile(training_data['serum_creatinine'],percent,interpolation='higher')
poly_norm_creatinine=np.polyfit(data_quant_creatinine,norm_quant_creatinine,deg=1,full=True)
print(poly_norm_creatinine)
# k=0.61, ssr=6.87
residuals_norm_creatinine=[(poly_norm_creatinine[0][0]*data_quant_creatinine[i]+poly_norm_creatinine[0][1])-norm_quant_creatinine[i] for i in range(len(percent))]
#print(residuals_norm_creatinine)

norm_quant_ejection=stats.norm.ppf(percent,loc=means[2],scale=stds[2])
data_quant_ejection=np.quantile(training_data['ejection_fraction'],percent,interpolation='higher')
poly_norm_ejection=np.polyfit(data_quant_ejection,norm_quant_ejection,deg=1,full=True)
print(poly_norm_ejection)
# k=1.06, ssr=114
residuals_norm_ejection=[(poly_norm_ejection[0][0]*data_quant_ejection[i]+poly_norm_ejection[0][1])-norm_quant_ejection[i] for i in range(len(percent))]
#print(residuals_norm_ejection)

# -----------------------------------------------------------
# log2-transform the serum creatinine and ejection fraction and compare to normal distribution
# Computing statistics for log2 transformed values
means_log2=np.log2(training_data[['age','serum_creatinine','ejection_fraction']]).mean()
stds_log2=np.log2(training_data[['age','serum_creatinine','ejection_fraction']]).std()

# create probplot
fig2,ax2=plt.subplots(nrows=2,ncols=1,num="Comparison of log2-transformed values to normal distribution",figsize=(9.0,4.8))
fig2.tight_layout(pad=2.0,w_pad=3.0,h_pad=3.0)
prob_creatinine_log2=stats.probplot(np.log2(training_data['serum_creatinine']),sparams=(means_log2[1],stds_log2[1]),dist=stats.norm,plot=ax2[0])
ax2[0].set_title('Probability plot for normal distribution vs log2-transformed serum creatinine')
print(prob_creatinine_log2[1])
ks=stats.kstest(np.log2(training_data['serum_creatinine']),'norm',args=(means_log2[1],stds_log2[1]))
print(f'Ks test for log2 creatinine vs norm: {ks}')

prob_ejection_log2=stats.probplot(np.log2(training_data['ejection_fraction']),sparams=(means_log2[2],stds_log2[2]),dist=stats.norm,plot=ax2[1])
ax2[1].set_title('Probability plot for normal distribution vs log2-transformed ejection')
print(prob_ejection_log2[1])
plt.show()
ks=stats.kstest(np.log2(training_data['ejection_fraction']),'norm',args=(means_log2[2],stds_log2[2]))
print(f'Ks test for log2 ejection vs norm: {ks}')

# compare quantiles

norm_log2_quant_creatinine=stats.norm.ppf(percent,loc=means_log2[1],scale=stds_log2[1])
data_log2_quant_creatinine=np.quantile(np.log2(training_data['serum_creatinine']),percent,interpolation='higher')
poly_norm_log2_creatinine=np.polyfit(data_log2_quant_creatinine,norm_log2_quant_creatinine,deg=1,full=True)
print(poly_norm_log2_creatinine)
# k=0.85, ssr=0.85
residuals_log2_creatinine=[(poly_norm_log2_creatinine[0][0]*data_log2_quant_creatinine[i]+poly_norm_log2_creatinine[0][1])-norm_log2_quant_creatinine[i] for i in range(len(percent))]
#print(residuals_log2_creatinine)

norm_log2_quant_ejection=stats.norm.ppf(percent,loc=means_log2[2],scale=stds_log2[2])
data_log2_quant_ejection=np.quantile(np.log2(training_data['ejection_fraction']),percent,interpolation='higher')
poly_norm_log2_ejection=np.polyfit(data_log2_quant_ejection,norm_log2_quant_ejection,deg=1,full=True)
print(poly_norm_log2_ejection)
# k=1.02, ssr=0.18
residuals_log2_creatinine=[(poly_norm_log2_ejection[0][0]*data_log2_quant_ejection[i]+poly_norm_log2_ejection[0][1])-norm_log2_quant_ejection[i] for i in range(len(percent))]
#print(residuals_log2_ejection)

# -----------------------------------------------------------
# compare to a gamma distribution

params_gamma_creatinine=stats.gamma.fit(training_data['serum_creatinine'])
params_gamma_ejection=stats.gamma.fit(training_data['ejection_fraction'])
# returns MLE for the parameters of the distribution, in a tuple with order shape, loc, scale

# compare creatinine to gamma distribution

# create probplot
fig3,ax3=plt.subplots(nrows=2,ncols=1,num="Comparison to gamma distribution",figsize=(9.0,4.8))
fig3.tight_layout(pad=2.0,w_pad=3.0,h_pad=3.0)
prob_creatinine_gamma=stats.probplot(training_data['serum_creatinine'],sparams=(params_gamma_creatinine),dist=stats.gamma,plot=ax3[0])
ax3[0].set_title('Probability plot for gamma distribution versus serum creatinine')
print(prob_creatinine_gamma[1])
# perform ks test
ks=stats.kstest(training_data['serum_creatinine'],'gamma',args=(params_gamma_creatinine))
print(f'Ks test for creatinine vs gamma: {ks}')

# compare ejection fraction to a gamma distribution

# create probplot
prob_ejection_gamma=stats.probplot(training_data['ejection_fraction'],sparams=(params_gamma_ejection),dist=stats.gamma,plot=ax3[1])
ax3[1].set_title('Probability plot for gamma distribution versus ejection fraction')
print(prob_ejection_gamma[1])
plt.show()
# perform ks test
ks=stats.kstest(training_data['ejection_fraction'],'gamma',args=(params_gamma_ejection))
print(f'Ks test ejection vs gamma: {ks}')

# compare creatinine to gamma distribution
gamma_quant_creatinine=stats.gamma.ppf(percent,params_gamma_creatinine[0],loc=params_gamma_creatinine[1],scale=params_gamma_creatinine[2])
data_quant_creatinine=np.quantile(training_data['serum_creatinine'],percent,interpolation="higher")
poly_gamma_creatinine=np.polyfit(data_quant_creatinine,gamma_quant_creatinine,deg=1,full=True)
print(poly_gamma_creatinine)
# k=0.82, ssr=0.76
residuals_gamma_creatinine=[(poly_gamma_creatinine[0][0]*data_quant_creatinine[i]+poly_gamma_creatinine[0][1])-gamma_quant_creatinine[i] for i in range(len(percent))]
#print(residuals_gamma_creatinine)

gamma_quant_ejection=stats.gamma.ppf(percent,params_gamma_ejection[0],loc=params_gamma_ejection[1],scale=params_gamma_ejection[2])
data_quant_ejection=np.quantile(training_data['ejection_fraction'],percent,interpolation="higher")
poly_gamma_ejection=np.polyfit(data_quant_ejection,gamma_quant_ejection,deg=1,full=True)
print(poly_gamma_ejection)
# k=1.07, ssr=134. Much error from the last point.
residuals_gamma_ejection=[(poly_gamma_ejection[0][0]*data_quant_ejection[i]+poly_gamma_ejection[0][1])-gamma_quant_ejection[i] for i in range(len(percent))]
#print(residuals_gamma_ejection)

# -----------------------------------------------------------
# compare to a  a chi2 distribution

params_chi2_creatinine=stats.chi2.fit(training_data['serum_creatinine'])
params_chi2_ejection=stats.chi2.fit(training_data['ejection_fraction'])
# returns MLE for the parameters of the distribution, in a tuple with order shape, loc, scale

# compare creatinine to chi2 distribution

# create probplot
fig4,ax4=plt.subplots(nrows=2,ncols=1,num="Comparison to chi2 distribution",figsize=(9.0,4.8))
fig4.tight_layout(pad=2.0,w_pad=3.0,h_pad=3.0)
prob_creatinine_chi2=stats.probplot(training_data['serum_creatinine'],sparams=(params_chi2_creatinine),dist=stats.chi2,plot=ax4[0])
ax4[0].set_title('Probability plot for chi2 distribution versus serum creatinine')
print(prob_creatinine_chi2[1])
# perform ks test
ks=stats.kstest(training_data['serum_creatinine'],'chi2',args=(params_chi2_creatinine))
print(f'Ks test for creatinine vs chi2: {ks}')

# compare ejection to a chi2 distribution

# create probplot
prob_ejection_chi2=stats.probplot(training_data['ejection_fraction'],sparams=(params_chi2_ejection),dist=stats.chi2,plot=ax4[1])
ax4[1].set_title('Probability plot for chi2 distribution versus ejection fraction')
print(prob_ejection_chi2[1])
plt.show()
# perform ks test
ks=stats.kstest(training_data['ejection_fraction'],'chi2',args=(params_chi2_ejection))
print(f'Ks test for ejection vs chi2: {ks}')

# compare quantiles
chi2_quant_creatinine=stats.chi2.ppf(percent,params_chi2_creatinine[0],loc=params_chi2_creatinine[1],scale=params_chi2_creatinine[2])
poly_chi2_creatinine=np.polyfit(data_quant_creatinine,chi2_quant_creatinine,deg=1,full=True)
print(poly_chi2_creatinine)
# k=0.58, ssr=0.75
residuals_chi2_creatinine=[(poly_chi2_creatinine[0][0]*data_quant_creatinine[i]+poly_chi2_creatinine[0][1])-chi2_quant_creatinine[i] for i in range(len(percent))]
#print(residuals_chi2_creatinine)

chi2_quant_ejection=stats.chi2.ppf(percent,params_chi2_ejection[0],loc=params_chi2_ejection[1],scale=params_chi2_ejection[2])
poly_chi2_ejection=np.polyfit(data_quant_ejection,chi2_quant_ejection,deg=1,full=True)
print(poly_chi2_ejection)
# k=1.07, ssr=165
residuals_chi2_ejection=[(poly_chi2_ejection[0][0]*data_quant_ejection[i]+poly_chi2_ejection[0][1])-chi2_quant_ejection[i] for i in range(len(percent))]
#print(residuals_chi2_ejection)

# -----------------------------------------------------------
# transform data with boxcox

creatinine_boxcox=stats.boxcox(training_data['serum_creatinine'])[0]
ejection_boxcox=stats.boxcox(training_data['ejection_fraction'])[0]

means_boxcox=[creatinine_boxcox.mean(),ejection_boxcox.mean()]
stds_boxcox=[creatinine_boxcox.std(),ejection_boxcox.std()]

fig5,ax5=plt.subplots(nrows=2,ncols=1,num="Comparison of boxcox values to normal distribution",figsize=(9.0,4.8))
fig5.tight_layout(pad=2.0,w_pad=3.0,h_pad=3.0)
prob_creatinine_box=stats.probplot(creatinine_boxcox,sparams=(means_boxcox[0],stds_boxcox[0]),plot=ax5[0])
ax5[0].set_title('Probability plot for normal distribution versus boxcox transformed creatinine')
print(prob_creatinine_box[1])
# perform ks test
ks=stats.kstest(creatinine_boxcox,'norm',args=(means_boxcox[0],stds_boxcox[0]))
print(f'Ks test for boxcox creatinine vs norm: {ks}')

prob_ejection_box=stats.probplot(ejection_boxcox,sparams=(means_boxcox[1],stds_boxcox[1]),plot=ax5[1])
ax5[1].set_title('Probability plot for normal distribution versus boxcox transformed ejection')
print(prob_ejection_box[1])
ks=stats.kstest(ejection_boxcox,'norm',args=(means_boxcox[1],stds_boxcox[1]))
print(f'Ks test for boxcox ejection vs norm: {ks}')
plt.show()

# compare quantiles

norm_box_quant_creatinine=stats.norm.ppf(percent, loc=means_boxcox[0],scale=stds_boxcox[0])
data_box_quant_creatinine=np.quantile(creatinine_boxcox,percent,interpolation='higher')
poly_box_creatinine=np.polyfit(data_box_quant_creatinine,norm_box_quant_creatinine,deg=1,full=True)
print(poly_box_creatinine)

norm_box_quant_ejection=stats.norm.ppf(percent, loc=means_boxcox[1],scale=stds_boxcox[1])
data_box_quant_ejection=np.quantile(ejection_boxcox,percent,interpolation='higher')
poly_box_ejection=np.polyfit(data_box_quant_ejection,norm_box_quant_ejection,deg=1,full=True)
print(poly_box_ejection)

# -----------------------------------------------------------
# Hypothesis testing

living=training_data[training_data['DEATH_EVENT']==0]
dead=training_data[training_data['DEATH_EVENT']==1]
means_DE=training_data[['age','serum_creatinine','ejection_fraction','serum_sodium','DEATH_EVENT']].groupby('DEATH_EVENT').mean()
stds_DE=training_data[['age','serum_creatinine','ejection_fraction','serum_sodium','DEATH_EVENT']].groupby('DEATH_EVENT').std()
# look at means and standard deviations for each variable and group
print(means_DE)
print(stds_DE)

# Two sample t test - do the variable means differ significantly between the two groups?

# print number of objects in each sample
print(training_data['DEATH_EVENT'].value_counts())

# large sample sizes means we can assume gaussian distribution of the means.
# we assume each sample contains measurements from  I.I.D. objects and  that the samples are indipendent.
# for ejection, the variance among the dead and living seem equal. Not in creatinine though it is unclear whether the difference is significant. We will therefore assume the variance is not equal in any case.
# significance level is set to 5 %.

print(stats.ttest_ind(dead[['age','serum_creatinine','ejection_fraction','serum_sodium']],living[['age','serum_creatinine','ejection_fraction','serum_sodium']],axis=0,equal_var=False))
# significant difference for all four. 

# binomial test - do more than 50% of the patients die?
# significance level: 5 %

print(stats.binom_test(np.sum(training_data['DEATH_EVENT']),n=len(training_data.index),p=0.5,alternative="two-sided"))
# p=0.18, not significant



# -----------------------------------------------------------
# Setting up and testing the models:

# The chosen predictive variables:
pred_vars = ['age', 'ejection_fraction', 'serum_creatinine', 'serum_sodium']
# Class variable is whether or not the patient has died at the follow-up:
class_var = 'DEATH_EVENT'

X_training = training_data[pred_vars]
Y_training = training_data[class_var]
X_val = val_data[pred_vars]
Y_val = val_data[class_var]
X_test = test_data[pred_vars]
Y_test = test_data[class_var]

#Preform logistic regression:
clf = LogisticRegression().fit(X_training,Y_training)
Y_pred = clf.predict(X_val)

#Print the result of the logistic regression:
print("\n\n\tLogistic regression:")
print("Accuracy score, classification report, and confusion matrix of the Logistic Regression:")
print("Accuracy score: %.3f" %accuracy_score(Y_val, Y_pred))
print("Recall score: %.3f" %recall_score(Y_val, Y_pred))
print("F1 score: %.3f" %f1_score(Y_val, Y_pred))
print("Classification report:\n", classification_report(Y_val, Y_pred))
print("\nConfusion matrix:\n", confusion_matrix(Y_val, Y_pred))

#Saving the predictions from the Logistic regression for the mcnemars test.
y_model_Logreg = np.array(Y_pred)

#scaling data to optimize KNN-model
sca = StandardScaler()
sca.fit(X_training)
X_training = sca.transform(X_training)
X_val = sca.transform(X_val)
X_test = sca.transform(X_test)

#finding the optimal k by running the following loop
#for k in range(1, 100, 4):
#    knn_model = KNeighborsClassifier(k, p = 2, metric='minkowski')
#    knn_model.fit(X_training, Y_training)
#    Y_pred = knn_model.predict(X_val)

#    print("Resultat för KNN:", "K=", k, "\n" )
#    print(accuracy_score(Y_val, Y_pred), "\n")
#    print(classification_report(Y_val, Y_pred))
#    print(confusion_matrix(Y_val, Y_pred))

# k = 9 is chosen to get high accuracy and low False negative
# Perform KNN
k=9
knn_model = KNeighborsClassifier(k, p = 2, metric='minkowski')
knn_model.fit(X_training, Y_training)
Y_pred = knn_model.predict(X_val)

#Print results for KNN
print("\n\n\tkNN classification:")
print("Accuracy_score, classification_report and confusion_matrix of the KNN with K = {}:".format(k))
print("Accuracy score: %.3f" %accuracy_score(Y_val, Y_pred))
print("Recall score: %.3f" %recall_score(Y_val, Y_pred))
print("F1 score: %.3f" %f1_score(Y_val, Y_pred))
print("Classification report:\n", classification_report(Y_val, Y_pred))
print("\nConfusion matrix:\n", confusion_matrix(Y_val, Y_pred))

#creating Contingency table for Mcnemar's test.
y_model_knn = np.array(Y_pred)
y_target = np.array(Y_val)
tb = mcnemar_table(y_target=y_target, y_model1=y_model_Logreg, y_model2=y_model_knn)

#Using Mcnemars exact test to compare the classifiers and see if the result is significant.
chi2, p = mc(ary=tb, exact=True)

#Print results from Mcnemar's test
print("\nMcnemar's test:")
print("\nContingency table:\n",tb)
print('\nchi-squared: %.3f' %chi2)
print('p-value:%.3f' %p)

#Comparing p-value to alpha and printing result
alpha = 0.05
if p > alpha:
	print('\n','The models does not have significantly different proportions of errors (fails to reject H0)', '\n')
else:
	print('\n','The models have significantly different proportions of errors (succeeds to reject H0)', '\n')

#Preferming the chosen classifier on the test-data:
clf = LogisticRegression().fit(X_training,Y_training)
Y_pred = clf.predict(X_test)

print("Accuracy_score, classification_report and confusion_matrix of the Logistic Regression on test data(our preferred algorithm): ")
print("\nAccuracy score: %.3f" %accuracy_score(Y_test, Y_pred))
print("\nClassification report:", classification_report(Y_test, Y_pred, zero_division = 0))
print("\nConfusion matrix:\n", confusion_matrix(Y_test, Y_pred))

# The recall and f1-score will be 0, because the true positive + false negative is 0.
# This is because there were no data points with positive outcomes in the test set.


